/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Database_Layer.DatabaseConnection;
import Model.Admin;
import Model.Conference;
import Model.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Akansha Gupta
 */
@WebServlet(urlPatterns = {"/RegisterUser"})
public class RegisterUser extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet RegisterUser</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet RegisterUser at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
              String FName = request.getParameter("First Name");
            String MName = request.getParameter("Middle Name");
            String LName = request.getParameter("Last Name");
            String username = request.getParameter("username");
            String email = request.getParameter("email id");
            String password = request.getParameter("password");
            String role = request.getParameter("redirect_to");
            String sex = request.getParameter("gender");
            String conf_name = request.getParameter("topic");
           
            int i =User.signup(email,password,FName,MName,LName,role,username,sex);
             int conf_id = 0 ;
            if(conf_name!=null || conf_name!="" )
            {
           Conference confff = Conference.GetConferenceByName(conf_name);
           conf_id = confff.conf_id;
            }
            
            if(role.equals("1"))
            {
            response.sendRedirect("/WebApplication1/html/imEvent/demo.ovatheme.com/eventmana/wp-login456e.html?mess=Congrats Registration done successfully.Login with your credential");
            }
            else
            {
                
                 if (role.equals("2"))
                {
                      PreparedStatement ps1;
        ResultSet rs1;
                      ps1=DatabaseConnection.getPreparedStatement("Select * from registration_table where username=? and email_id=?");
        ps1.setString(1,username);
        ps1.setString(2,email);
            
       rs1 =  ps1.executeQuery();
                    
                    
          if (rs1.next())
           {
                int idd = rs1.getInt("user_id");
                ps1=DatabaseConnection.getPreparedStatement("insert into reviewer_conf_table(user_id,conf_id,expertize_area) values(?,?,?)");
                ps1.setInt(1,idd);
                ps1.setInt(2, conf_id);
                 ps1.setString(3, "");
          ps1.executeUpdate();
           }
                         
                    
                    
                    
                    
                    
                response.sendRedirect("/WebApplication1/html/imEvent/demo.ovatheme.com/eventmana/indextpc.jsp?mess=Congrats Registration done successfully.Login with your credential");
                }
                if (role.equals("3"))
                {
                response.sendRedirect("/WebApplication1/html/imEvent/demo.ovatheme.com/eventmana/wp-login456e.html?mess=Congrats Registration done successfully.Login with your credential");
                }
                if(role.equals("4"))
                {
                    
                    //this is my tpc ..so add it to tpc_table configuration
                    
                    PreparedStatement ps1;
        ResultSet rs1;
                      ps1=DatabaseConnection.getPreparedStatement("Select * from registration_table where username=? and email_id=?");
        ps1.setString(1,username);
        ps1.setString(2,email);
            
       rs1 =  ps1.executeQuery();
           
           if (rs1.next())
           {
                int idd = rs1.getInt("user_id");
                ps1=DatabaseConnection.getPreparedStatement("insert into tpc_conf(userid,confid) values(?,?)");
                ps1.setInt(1,idd);
                ps1.setInt(2, conf_id);
          ps1.executeUpdate();
           }
             
        
                    
                    
                    
                    
                     response.sendRedirect("/WebApplication1/html/imEvent/demo.ovatheme.com/eventmana/indexking.jsp?mess=Congrats Registration done successfully.Login with your credential");
               
                }
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(RegisterUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(RegisterUser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
