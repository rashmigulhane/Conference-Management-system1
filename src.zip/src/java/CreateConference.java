/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Model.Admin;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Akansha Gupta
 */
@WebServlet(urlPatterns = {"/CreateConference"})
public class CreateConference extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CreateConference</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CreateConference at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
            String CName = request.getParameter("Conference Name");
            String CArea = request.getParameter("Area");
            String desc = request.getParameter("description");
            String regstrt = request.getParameter("Registration start date");
            String regend = request.getParameter("Registration end date");
            String abstarct = request.getParameter("Abstract submission deadline");
            String papersub = request.getParameter("Paper submission deadline");
            String paperaccept = request.getParameter("Deadline for paper Acceptance");
             String charge = request.getParameter("charge");
             String topic = request.getParameter("Topics");
            Admin.createConference(CName,CArea,desc,regstrt,regend,abstarct,papersub,paperaccept,charge,topic);
            response.sendRedirect("/WebApplication1/html/imEvent/demo.ovatheme.com/eventmana/indexking.jsp?message=conference added successfully");
           
           // Admin.createConference();
        }
        catch(Exception e)
        {
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
