package Database_Layer;


import com.mysql.jdbc.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tarun
 */
public class DatabaseConnection {
      private static String Database_driver = "com.mysql.jdbc.Driver";
        private static    String Database_username = "root";
        private static    String Database_password = "";
       private static   String Database_url = "jdbc:mysql://localhost/con_man1";
       

    public static ResultSet getResultSet (String query)
    {
        try {
            
            //database  connectivity
            Class.forName(Database_driver);
           
            Connection connection = DriverManager.getConnection(Database_url, Database_username, Database_password);
           
            PreparedStatement ps = connection.prepareStatement(query);
            
            ResultSet rs = ps.executeQuery();
          
            return rs;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
        }  
        return null;
    }
     public static PreparedStatement getPreparedStatement (String query)
    {
        try {System.out.println(query);
            //database  connectivity
            Class.forName(Database_driver);
            
            Connection connection = DriverManager.getConnection(Database_url, Database_username, Database_password);
            
            PreparedStatement ps = connection.prepareStatement(query);
 
            return ps;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(DatabaseConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
