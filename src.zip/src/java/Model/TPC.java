/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Akansha Gupta
 */
public class TPC extends User{
    
    
   
    
    
    
    public static ArrayList assignPaper(String conf_name,String choice,String paper_id) throws SQLException
    {
         ArrayList a =new ArrayList();
        
        if(choice.equals("load"))
        {
        
        Conference c = Conference.GetConferenceByName(conf_name);
        int c_id = c.conf_id;
        PreparedStatement ps1;
        ResultSet rs1;
         ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=? and status=?");
         ps1.setInt(1, c_id);
         ps1.setString(2, "Paper submitted");
          rs1=ps1.executeQuery();
       while(rs1.next())
       {
           Paper p =new Paper();
           p.paper_id = rs1.getInt("paper_id");
           p.title = rs1.getString("title");
           a.add(p);
       }
        }
        
        
           
        
        
        if(choice.equals("assign"))
        {
            
             Conference c = Conference.GetConferenceByName(conf_name);
        int c_id = c.conf_id;
            
            PreparedStatement ps1;
        ResultSet rs1;
         ResultSet rs2;
           ps1=DatabaseConnection.getPreparedStatement("select * from reviewer_interest where conf_id=? and paper_id=?");
      
         ps1.setInt(1, c_id);
         ps1.setInt(2,Integer.parseInt(paper_id) );
            
              rs1=ps1.executeQuery();
       while(rs1.next())
       {
           
         int rev_id =  rs1.getInt("user_id");
         
            ps1=DatabaseConnection.getPreparedStatement("select * from registration_table where user_id=?");
                 ps1.setInt(1, rev_id);
                  rs2=ps1.executeQuery();
              
         
         
            if(rs2.next())
                  {
                     Author u = new Author();
                     u.email_id = rs2.getString("email_id");
                     u.first_name =rs2.getString("first_name");
                     u.last_name = rs2.getString("last_name");
                     u.gender = rs2.getString("gender");
                     u.username = rs2.getString("username");
                     u.userid = rs2.getInt("user_id");
                     a.add(u);
                  }
       }
        }
        
        
        return a;
    }
    
    
    
    
    public static void createRev(int userid, String username) throws SQLException {
   PreparedStatement ps1;
        ResultSet rs1;
       Conference c = Conference.GetConferenceByName(username);
       int c_id =c.conf_id;
          ps1=DatabaseConnection.getPreparedStatement("insert into reviewer_conf_table(user_id,conf_id,expertize_area) values(?,?,?)");
                ps1.setInt(1,userid);
                ps1.setInt(2, c_id);
                 ps1.setString(3, "");
          ps1.executeUpdate();
    
    }
    
    
    
    public static ArrayList viewParticipant(String conf_name) throws SQLException
    {
         ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
         ResultSet rs2;
     Conference c =   Conference.GetConferenceByName(conf_name);
     int c_id = c.conf_id;
     
        ps1=DatabaseConnection.getPreparedStatement("select * from author_conf where conf_id=?");
        ps1.setInt(1, c_id);
          rs1=ps1.executeQuery();
            while(rs1.next())
            {
                int user_id = rs1.getInt("user_id");
                 ps1=DatabaseConnection.getPreparedStatement("select * from registration_table where user_id=?");
                 ps1.setInt(1, user_id);
                  rs2=ps1.executeQuery();
                  if(rs2.next())
                  {
                     Author u = new Author();
                     u.email_id = rs2.getString("email_id");
                     u.first_name =rs2.getString("first_name");
                     u.last_name = rs2.getString("last_name");
                     u.gender = rs2.getString("gender");
                     u.username = rs2.getString("username");
                     list.add(u);
                  }
                  
                  
                  
            }
            return list;
    }
    
    //get participant who have subitted abstract in a particular conference
    public static ArrayList viewAbstract(String conf_name) throws SQLException
    {
         ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
         ResultSet rs2;
     Conference c =   Conference.GetConferenceByName(conf_name);
     int c_id = c.conf_id;
     
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=? and status=?");
        ps1.setInt(1, c_id);
         ps1.setString(2, "Abstract submitted");
          rs1=ps1.executeQuery();
            while(rs1.next())
            {
                int user_id = rs1.getInt("user_id");
                 ps1=DatabaseConnection.getPreparedStatement("select * from registration_table where user_id=?");
                 ps1.setInt(1, user_id);
                  rs2=ps1.executeQuery();
                  if(rs2.next())
                  {
                     Author u = new Author();
                     u.email_id = rs2.getString("email_id");
                     u.first_name =rs2.getString("first_name");
                     u.last_name = rs2.getString("last_name");
                     u.gender = rs2.getString("gender");
                     u.username = rs2.getString("username");
                     list.add(u);
                  }
                  
                  
                  
            }
            return list;
    }
    
    
    
    
    
    
    
     public static ArrayList viewPaper(String conf_name) throws SQLException
    {
         ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
         ResultSet rs2;
     Conference c =   Conference.GetConferenceByName(conf_name);
     int c_id = c.conf_id;
     
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=? and status=?");
        ps1.setInt(1, c_id);
         ps1.setString(2, "Paper submitted");
          rs1=ps1.executeQuery();
            while(rs1.next())
            {
                int user_id = rs1.getInt("user_id");
                 ps1=DatabaseConnection.getPreparedStatement("select * from registration_table where user_id=?");
                 ps1.setInt(1, user_id);
                  rs2=ps1.executeQuery();
                  if(rs2.next())
                  {
                     Author u = new Author();
                     u.email_id = rs2.getString("email_id");
                     u.first_name =rs2.getString("first_name");
                     u.last_name = rs2.getString("last_name");
                     u.gender = rs2.getString("gender");
                     u.username = rs2.getString("username");
                     list.add(u);
                  }
                  
                  
                  
            }
            return list;
    }
    
    
    public static ArrayList viewPAccespted(String conf_name) throws SQLException
    {
         ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
         ResultSet rs2;
     Conference c =   Conference.GetConferenceByName(conf_name);
     int c_id = c.conf_id;
     
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=? and status=?");
        ps1.setInt(1, c_id);
         ps1.setString(2, "Paper Accepted");
          rs1=ps1.executeQuery();
            while(rs1.next())
            {
                int user_id = rs1.getInt("user_id");
                 ps1=DatabaseConnection.getPreparedStatement("select * from registration_table where user_id=?");
                 ps1.setInt(1, user_id);
                  rs2=ps1.executeQuery();
                  if(rs2.next())
                  {
                     Author u = new Author();
                     u.email_id = rs2.getString("email_id");
                     u.first_name =rs2.getString("first_name");
                     u.last_name = rs2.getString("last_name");
                     u.gender = rs2.getString("gender");
                     u.username = rs2.getString("username");
                     list.add(u);
                  }
                  
                  
                  
            }
            return list;
    }
    
    
    
    
    
    
    
     public static ArrayList viewPRejected(String conf_name) throws SQLException
    {
         ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
         ResultSet rs2;
     Conference c =   Conference.GetConferenceByName(conf_name);
     int c_id = c.conf_id;
     
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=? and status=?");
        ps1.setInt(1, c_id);
         ps1.setString(2, "Paper Rejected");
          rs1=ps1.executeQuery();
            while(rs1.next())
            {
                int user_id = rs1.getInt("user_id");
                 ps1=DatabaseConnection.getPreparedStatement("select * from registration_table where user_id=?");
                 ps1.setInt(1, user_id);
                  rs2=ps1.executeQuery();
                  if(rs2.next())
                  {
                     Author u = new Author();
                     u.email_id = rs2.getString("email_id");
                     u.first_name =rs2.getString("first_name");
                     u.last_name = rs2.getString("last_name");
                     u.gender = rs2.getString("gender");
                     u.username = rs2.getString("username");
                     list.add(u);
                  }
                  
                  
                  
            }
            return list;
    }
     
     
     
     
     
     
     
     public static ArrayList viewPPayment(String conf_name) throws SQLException
    {
         ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
         ResultSet rs2;
     Conference c =   Conference.GetConferenceByName(conf_name);
     int c_id = c.conf_id;
     
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=? and status=?");
        ps1.setInt(1, c_id);
         ps1.setString(2, "Payment made");
          rs1=ps1.executeQuery();
            while(rs1.next())
            {
                int user_id = rs1.getInt("user_id");
                 ps1=DatabaseConnection.getPreparedStatement("select * from registration_table where user_id=?");
                 ps1.setInt(1, user_id);
                  rs2=ps1.executeQuery();
                  if(rs2.next())
                  {
                     Author u = new Author();
                     u.email_id = rs2.getString("email_id");
                     u.first_name =rs2.getString("first_name");
                     u.last_name = rs2.getString("last_name");
                     u.gender = rs2.getString("gender");
                     u.username = rs2.getString("username");
                     list.add(u);
                  }
                  
                  
                  
            }
            return list;
    }
    
    
    
    
    
    
    
    
    
    
    public static ArrayList AssignReviwer(int userid,String choice) throws SQLException
    {
         ArrayList list = new ArrayList();
       
        if(choice.equals("ALLCONFBYTPC"))
        {
        ResultSet rs1;
        PreparedStatement ps1;
         Conference d=new Conference();
       
        ps1 = DatabaseConnection.getPreparedStatement("select * from tpc_conf where userid=?");
        ps1.setInt(1, userid);
         rs1=ps1.executeQuery();
         while(rs1.next())
         {
                     list.add(d.GetConferenceByID(rs1.getInt("confid")));
      
         }
        }
        return list;
    }
    
    
    
    
     public static ArrayList GetAllConferenceRegisteredByTPC(int user_id) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        ps1=DatabaseConnection.getPreparedStatement("select * from tpc_conf where userid=?");
         try {
            
        ps1.setInt(1,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
               list.add(d.GetConferenceByID(rs1.getInt("confid")));
            }

        
    }
          catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    
    public static ArrayList viewAcceptedPaper(String choice,int user_id,String conf_name) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        PreparedStatement ps2;
        ResultSet rs2;
     
        try
        {
        if (choice.equals("Conf"))
        {
        ps1=DatabaseConnection.getPreparedStatement("select * from tpc_conf where user_id=?");
        ps1.setInt(1,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(d.GetConferenceByID(rs1.getInt("confid")));
            }
            return list;
        }
        if (choice.equals("Paper"))
        {
            Conference c =Conference.GetConferenceByName(conf_name);
        ps1=DatabaseConnection.getPreparedStatement("select * from reviewer_table where conf_id=? and technical_quality>0");
        ps1.setInt(1,c.conf_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              Paper fds=Paper.getPaper(rs1.getInt("paper_id"));
              
              fds.finalScore = rs1.getString("finalScore");
              fds.comments = rs1.getString("comments");
              int revid = rs1.getInt("user_id");
              User a = User.getDetails(revid);
              fds.revname = a.username;
              
               list.add(fds);
            }
            return list;
        }
        
        
         
     
     }catch(Exception e)
     {
         
     }
         return null;
     }
    
    
    
    
     public static ArrayList previewPaper(String choice,int user_id,String conf_name) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        try
        {
        if (choice.equals("Conf"))
        {
        ps1=DatabaseConnection.getPreparedStatement("select * from tpc_conf where userid=?");
        ps1.setInt(1,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(d.GetConferenceByID(rs1.getInt("confid")));
            }
            return list;
        }
        if (choice.equals("Paper"))
        {
            Conference c =Conference.GetConferenceByName(conf_name);
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=?");
        ps1.setInt(1,c.conf_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(Paper.getPaper(rs1.getInt("paper_id")));
            }
            return list;
        }
        
        
         
     
     }catch(Exception e)
     {
         
     }
         return null;
     }
     
    
    
    
    
    
    /*public static ArrayList AcceptPaper(String choice,int user_id,String conf_name) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        try
        {
        if (choice.equals("Conf"))
        {
        ps1=DatabaseConnection.getPreparedStatement("select * from reviewer_conf_table where user_id=?");
        ps1.setInt(1,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(d.GetConferenceByID(rs1.getInt("conf_id")));
            }
            return list;
        }
        if (choice.equals("Paper"))
        {
            Conference c =Conference.GetConferenceByName(conf_name);
        ps1=DatabaseConnection.getPreparedStatement("select * from reviewer_table where conf_id=? and technical_quality>0");
        ps1.setInt(1,c.conf_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              Paper fds=Paper.getPaper(rs1.getInt("paper_id"));
              
              fds.finalScore = rs1.getString("finalScore");
               list.add(fds);
            }
            return list;
        }
        
        
         
     
     }catch(Exception e)
     {
         
     }
         return null;
     }

     
     */
     
     
    public static void AcceptPaper(String[] Accept, String conf_name) throws SQLException {
         Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        Conference c =Conference.GetConferenceByName(conf_name);
        int conf_id = c.conf_id;
         if (Accept != null) 
            {
                for (int i = 0; i < Accept.length; i++) 
                {
                    ps1=DatabaseConnection.getPreparedStatement("update paper_table set status=? where paper_id=?");
                    ps1.setString(1,"Paper Accepted");
                    ps1.setInt(2,Integer.parseInt(Accept[i]));
        ps1.executeUpdate(); 
                }
            }
        
    }
     
    
    
    
    
    public static void RejectPaper(String[] Accept, String conf_name) throws SQLException {
         Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        Conference c =Conference.GetConferenceByName(conf_name);
        int conf_id = c.conf_id;
         if (Accept != null) 
            {
                for (int i = 0; i < Accept.length; i++) 
                {
                    ps1=DatabaseConnection.getPreparedStatement("update paper_table set status=? where paper_id=?");
                    ps1.setString(1,"Paper Rejected");
                    ps1.setInt(2,Integer.parseInt(Accept[i]));
        ps1.executeUpdate(); 
                }
            }
        
    }

    public static void TPCSelectsReviwers(String[] rev_interested_id, String conf_name, String p_id) throws SQLException {
 
    Conference c=Conference.GetConferenceByName(conf_name);
    int conf_id = c.conf_id;
    PreparedStatement ps1;
  for(int i=0;i<rev_interested_id.length;i++)
  {
       ps1=DatabaseConnection.getPreparedStatement("insert into reviewer_table(user_id,paper_id,conf_id,comments,technical_quality,relevance,WritingStyle,Standard_English,UseOfReference,AppropriateTitle,lenght,abstract,finalScore) values(?,?,?,?,?,?,?,?,?,?,?,?,?)");
       ps1.setInt(1, Integer.parseInt(rev_interested_id[i]));
       ps1.setInt(2, Integer.parseInt(p_id));
        ps1.setInt(3, conf_id);
        ps1.setString(4,"ss");
        ps1.setInt(5, 0);
          ps1.setInt(6, 0);
           ps1.setInt(7, 0);
            ps1.setInt(8, 0);
            
             ps1.setInt(9, 0);
          ps1.setInt(10, 0);
           ps1.setInt(11, 0);
            ps1.setInt(12, 0);
            
            ps1.setString(13, "");
            
         ps1.executeUpdate();
      
  }
    
    
    
    
    }
     
     
}
    

