/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Akansha Gupta
 */
public class Admin  extends User{
    
    public static void createConference(String CName,String CArea,String desc,String regstrt,String regend,String abstarct,String papersub,String paperaccept,String charge,String topics)
    {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
         ps1=DatabaseConnection.getPreparedStatement("insert into conference_table(conf_name,description,Registration_start_date,Registration_end_date,abs_sub_deadline,paper_sub_deadline,paper_accepted_deadline,charge,Area_conference) values(?,?,?,?,?,?,?,?,?)");
       try {
            
        ps1.setString(1,CName);
        ps1.setString(2,desc);
        ps1.setString(3,regstrt);
        ps1.setString(4,regend);
        ps1.setString(5,abstarct);
        ps1.setString(6,papersub);
        ps1.setString(7,paperaccept);
        ps1.setInt(8,Integer.parseInt(charge));
        ps1.setString(9,CArea);
        
        
        ps1.executeUpdate();
        
       ps1=DatabaseConnection.getPreparedStatement("select * from conference_table where conf_name = ? and description=?");
   ps1.setString(1,CName);
   ps1.setString(2,desc);
         rs1=ps1.executeQuery();
          if(rs1.next())
            {
            int c_id  = rs1.getInt("conf_id");
            String[] parts = topics.split(",");
            int no =0;
            while(no<parts.length)
            {
                ps1=DatabaseConnection.getPreparedStatement("insert into conference_topics(conf_id,topic_name) values(?,?)");
                ps1.setInt(1, c_id);
                ps1.setString(2, parts[no]);
                ps1.executeUpdate();
                no=no+1;
            }
            
            
          
            }
        
       }
        catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void createTPC(int userid, String username) throws SQLException {
   PreparedStatement ps1;
        ResultSet rs1;
       Conference c = Conference.GetConferenceByName(username);
       int c_id =c.conf_id;
          ps1=DatabaseConnection.getPreparedStatement("insert into tpc_conf(userid,confid) values(?,?)");
                ps1.setInt(1,userid);
                ps1.setInt(2, c_id);
          ps1.executeUpdate();
    
    }
    
    
     public static void UpdateConferenceInfo(int userid, String username) throws SQLException {
   PreparedStatement ps1;
        ResultSet rs1;
       Conference c = Conference.GetConferenceByName(username);
       int c_id =c.conf_id;
          ps1=DatabaseConnection.getPreparedStatement("insert into tpc_conf(userid,confid) values(?,?)");
                ps1.setInt(1,userid);
                ps1.setInt(2, c_id);
          ps1.executeUpdate();
    
    }
     
     
     public static void ViewConferenceInfo(int userid, String username) throws SQLException {
   PreparedStatement ps1;
        ResultSet rs1;
       Conference c = Conference.GetConferenceByName(username);
       int c_id =c.conf_id;
          ps1=DatabaseConnection.getPreparedStatement("insert into tpc_conf(userid,confid) values(?,?)");
                ps1.setInt(1,userid);
                ps1.setInt(2, c_id);
          ps1.executeUpdate();
    
    }

}
