/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Akansha Gupta
 */
public class Paper {
  public int user_id;
    public int  conf_id;
    public int topic_id;
    public String title;
    public String abstractt;
    public String status;
    public String paper_name; 
    public String abstract_name; 
    public String Abs_sub;
    public String Paper_sub;
    
    public String Paper_Accepted;
    public String Payment_Made;
    
    
   public  String comments;
  public  String revname;
    public int paper_id;
     public String finalScore;
    PreparedStatement ps;
    ResultSet rs;
    public String topic_name;
    
    
    public static void getPaperAbstractSubmitted(int user_id)
    {
        PreparedStatement ps1;
        ResultSet rs1;
        ps1=DatabaseConnection.getPreparedStatement("select * from author_conf where user_id=?");
       
    }
    
    
    public static ArrayList GetAllAbstractConferenceSubmittedByuser(int user_id) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        
        ps1 = DatabaseConnection.getPreparedStatement("select topic_id,conf_id from paper_table where user_id=? and status=? or status=?");
         try {
            
        ps1.setInt(1,user_id);
        ps1.setString(2, "Abstract submitted");
        ps1.setString(3, "Paper submitted");
        
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              Conference connf =  d.GetConferenceByID(rs1.getInt("conf_id"));
              list.add(connf);
            }

        
    }
          catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
  public static Paper getPaper(int paperid)
  {
        Paper p =new Paper();
        
        PreparedStatement ps1;
        ResultSet rs1;
        
        ps1 = DatabaseConnection.getPreparedStatement("select * from paper_table where paper_id=?");
         try {
            
        ps1.setInt(1,paperid);
        p.Abs_sub = "No";
        p.Paper_sub="No";
        
        p.Paper_Accepted="YET TO DECIDE";
    p.Payment_Made="NOT YET";
        
        
        rs1=ps1.executeQuery();
            if(rs1.next())
            {
            p.topic_name = Conference_topic.getTopicName(rs1.getInt("topic_id"));
            p.conf_id =  rs1.getInt("conf_id");
            //p.abstractt =rs1.getBytes("abstract");
            //p.original_paper = rs1.getBytes("original_paper");
            p.status = rs1.getString("status");
            p.title = rs1.getString("title");
            p.paper_id = rs1.getInt("paper_id");
            p.abstract_name = rs1.getString("abstract_name");
                   p.paper_name = rs1.getString("paper_name");
     
        //    p.abstractt = rs1.getString("abstract");
              if(p.status.equals("Abstract submitted"))
              {
                   p.Abs_sub = "Yes";
        p.Paper_sub="No";
         p.Paper_Accepted="Yet to decide";
    p.Payment_Made="Not yet";
              }
              if(p.status.equals("Paper submitted"))
              {
                    p.Abs_sub = "Yes";
        p.Paper_sub="Yes";
         p.Paper_Accepted="Yet to decide";
    p.Payment_Made="Not yet";
              }
               if(p.status.equals("Paper Accepted"))
              {
                    p.Abs_sub = "Yes";
        p.Paper_sub="Yes";
         p.Paper_Accepted="Yes";
    p.Payment_Made="Not yet";
              }
               
               if(p.status.equals("Paper Rejected"))
              {
                    p.Abs_sub = "Yes";
        p.Paper_sub="Yes";
         p.Paper_Accepted="No";
    p.Payment_Made="No need";
              }
               
               
               if(p.status.equals("Payment made"))
              {
                    p.Abs_sub = "Yes";
        p.Paper_sub="Yes";
         p.Paper_Accepted="Yes";
    p.Payment_Made="Yes";
              }
              
              p.title = rs1.getString("title");
            }
       
        
    }
          catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
       
      return p;
  }
    
}
