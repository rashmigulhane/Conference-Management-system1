/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Akansha Gupta
 */
public abstract class User {
    
    public int userid;
    public String email_id;
    public String password;
    public String first_name;
    public String middle_name;
    public String last_name;
    public String role;
    public String username;
    public String gender;
    
    
    public static User getDetails(int id)
    {
        User u = new Author();
           PreparedStatement ps1;
        ResultSet rs1;
        ps1 = DatabaseConnection.getPreparedStatement("select * from registration_table where user_id=?");
        try {
            ps1.setInt(1,id);
             rs1=ps1.executeQuery();
            if(rs1.next())
            {
                u.username = rs1.getString("username");
            }
        } catch (SQLException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return u;
    }
    
    public static int signup(String email_id,String password,String first_name,String middle_name,String last_name,String role,String username,String gender )
    {
        
        int r=0;
        PreparedStatement ps1;
        ResultSet rs1;
         ps1=DatabaseConnection.getPreparedStatement("insert into registration_table(email_id,password,first_name,middle_name,last_name,role,username,gender) values(?,?,?,?,?,?,?,?)");
       try {
            
        ps1.setString(1,email_id);
        ps1.setString(2,password);
        ps1.setString(3,first_name);
        ps1.setString(4,middle_name);
        ps1.setString(5,last_name);
        ps1.setString(6,role);
        ps1.setString(7,username);
        
        ps1.setString(8,gender);
        
        
        ps1.executeUpdate();
        ps1=DatabaseConnection.getPreparedStatement("Select * from registration_table where username=? and email_id=?");
        ps1.setString(1,username);
        ps1.setString(2,email_id);
            
           rs1 =  ps1.executeQuery();
           
           if (rs1.next())
           {
              int i = rs1.getInt("user_id");
                  ps1=DatabaseConnection.getPreparedStatement("insert into login(username,password,role) values(?,?,?)");
       ps1.setString(1,username);
        ps1.setString(2,password);
        ps1.setInt(3,Integer.parseInt(role));
         r =   ps1.executeUpdate();
    
           }
    return r;
       }
        catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        } 
       return r;
    }
}
