/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Akansha Gupta
 */
public class Reviewer extends User{
    
    public String conf_name;
     public static ArrayList previewPaper(String choice,int user_id,String conf_name) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        try
        {
        if (choice.equals("Conf"))
        {
        ps1=DatabaseConnection.getPreparedStatement("select * from reviewer_conf_table where user_id=?");
        ps1.setInt(1,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(d.GetConferenceByID(rs1.getInt("conf_id")));
            }
            return list;
        }
        if (choice.equals("Paper"))
        {
            Conference c =Conference.GetConferenceByName(conf_name);
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=?");
        ps1.setInt(1,c.conf_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(Paper.getPaper(rs1.getInt("paper_id")));
            }
            return list;
        }
        
        
         
     
     }catch(Exception e)
     {
         
     }
         return null;
     }
     
     
     public static ArrayList ViewAssignedPapers(int user_id,String conf_name) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        try
        {
       
        
            Conference c =Conference.GetConferenceByName(conf_name);
        ps1=DatabaseConnection.getPreparedStatement("select * from reviewer_table where conf_id=? and user_id=?");
        ps1.setInt(1,c.conf_id);
        ps1.setInt(2,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(Paper.getPaper(rs1.getInt("paper_id")));
            }
            return list;
        
        
        
         
     
     }catch(Exception e)
     {
         
     }
         return null;
     }
     
       

    public static void selectPaperPreference(String[] paperchoice, int usr_id, String conf_name) {
        
        
        
        
         Conference c =  Conference.GetConferenceByName(conf_name);
      int Conf_id = c.conf_id;
       
        ResultSet rs1;
       
        
        try
        {
            if (paperchoice != null) 
            {
                for (int i = 0; i < paperchoice.length; i++) 
                {
                    
                     String query="INSERT INTO reviewer_interest  (user_id, paper_id, conf_id) VALUES(?,?,?)";
                           java.sql.PreparedStatement ps1=DatabaseConnection.getPreparedStatement(query);
               
                     ps1.setInt(1,usr_id);
            ps1.setInt(2,Integer.parseInt(paperchoice[i]));
            ps1.setInt(3,Conf_id);
                  ps1.executeUpdate();
      
                }
            }
        
        }catch(Exception e)
        {
             Logger.getLogger(Author.class.getName()).log(Level.SEVERE, null, e);
        }
        
    }

    public static void evaluatePaper(String user_id, String paper_id, String conf_id, String comments, String Quality, String Topic, String Style, String English, String Reference,String Appropriateness, String Length, String Abstract) {
 
   
        ResultSet rs1;
       
        
        try
        {
           
                    
                     String query="Update reviewer_table set comments=?,technical_quality=?, relevance=?,WritingStyle=?,Standard_English=?,UseOfReference=?,AppropriateTitle=?,lenght=?,abstract=?,finalScore=? where user_id = ? and paper_id = ? and conf_id = ?";
                           java.sql.PreparedStatement ps1=DatabaseConnection.getPreparedStatement(query);
               
                    
            
             ps1.setString(1,comments);
            ps1.setInt(2,Integer.parseInt(Quality));
            ps1.setInt(3,Integer.parseInt(Topic));
            
             ps1.setInt(4,Integer.parseInt(Style));
            ps1.setInt(5,Integer.parseInt(English));
            ps1.setInt(6,Integer.parseInt(Reference));
            
            
             
            ps1.setInt(7,Integer.parseInt(Appropriateness));
            ps1.setInt(8,Integer.parseInt(Length));
            
            ps1.setInt(9,Integer.parseInt(Abstract));
            float finalScore = 0;
      
            finalScore = ((Integer.parseInt(Quality))+Integer.parseInt(Topic)+Integer.parseInt(Style)+Integer.parseInt(English)+Integer.parseInt(Reference)+Integer.parseInt(Appropriateness)+Integer.parseInt(Length)+Integer.parseInt(Abstract));
           finalScore =finalScore/8;     
             ps1.setString(10,String.valueOf(finalScore));
             ps1.setInt(11,Integer.parseInt(user_id));
            ps1.setInt(12,Integer.parseInt(paper_id));
            ps1.setInt(13,Integer.parseInt(conf_id));
                  ps1.executeUpdate();
      
        
        }catch(Exception e)
        {
             Logger.getLogger(Author.class.getName()).log(Level.SEVERE, null, e);
        }
        
    
    
    
    }
    
    
    
    
    
    /*
     public static ArrayList viewAcceptedPaper(int user_id) {
        ArrayList list = new ArrayList();
        ArrayList plist = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        try
        {
        ps1=DatabaseConnection.getPreparedStatement("select * from reviewer_conf_table where user_id=?");
        ps1.setInt(1,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(d.GetConferenceByID(rs1.getInt("conf_id")));
            }
           
        
        int ss=0;
                while(ss<list.size())
                {
                    Conference c =Conference.GetConferenceByID(Integer.parseInt(list.get(ss).toString()));
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=? and status=Paper submitted");
        ps1.setInt(1,c.conf_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               plist.add(Paper.getPaper(rs1.getInt("paper_id")));
            }
            return list;
        
        
        
                }
     
     }catch(Exception e)
     {
         
     }
         return null;
     }
     
     
     
    
    
  */
     
    
    
    
    public static ArrayList viewAcceptedPaper(String choice,int user_id,String conf_name) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        try
        {
        if (choice.equals("Conf"))
        {
        ps1=DatabaseConnection.getPreparedStatement("select * from reviewer_conf_table where user_id=?");
        ps1.setInt(1,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(d.GetConferenceByID(rs1.getInt("conf_id")));
            }
            return list;
        }
        if (choice.equals("Paper"))
        {
            Conference c =Conference.GetConferenceByName(conf_name);
        ps1=DatabaseConnection.getPreparedStatement("select * from paper_table where conf_id=? and status='Paper Accepted' or status='Payment made'");
        ps1.setInt(1,c.conf_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
              
               list.add(Paper.getPaper(rs1.getInt("paper_id")));
            }
            return list;
        }
        
        
         
     
     }catch(Exception e)
     {
         
     }
         return null;
     }
     
}
