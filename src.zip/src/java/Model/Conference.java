/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Akansha Gupta
 */
public class Conference {

    private static String getMonth(String splitString) {
         //To change body of generated methods, choose Tools | Templates.
        String m_no = splitString;
        String month="";
        if (m_no.equals("01"))
        {
            month="January";
        }
        if (m_no.equals("02"))
        {
            month="February";
        }
        if (m_no.equals("03"))
        {
            month="March";
        }
        if (m_no.equals("04"))
        {
            month="April";
        }
        if (m_no.equals("05"))
        {
            month="May";
        }
        if (m_no.equals("06"))
        {
            month="June";
        }
        if (m_no.equals("07"))
        {
            month="July";
        }
         if (m_no.equals("08"))
        {
            month="August";
        }
          if (m_no.equals("09"))
        {
            month="September";
        }
           if (m_no.equals("10"))
        {
            month="October";
        }
            if (m_no.equals("11"))
        {
            month="November";
        }
             if (m_no.equals("12"))
        {
            month="December";
        }
        return month;
    }
 
    public String conf_name;
    public String Registration_start_date;
    public String Registration_end_date;
    public String abs_sub_deadline;
    public String paper_sub_deadline;
    public String paper_accepted_deadline;
    public int charge;
    public String desciption;
    public int conf_id;
    public String area;
    


    PreparedStatement ps;
    ResultSet rs;

    public static Conference GetConferenceByName(String conference_name) {
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        ps1=DatabaseConnection.getPreparedStatement("select * from conference_table where conf_name=?");
        try {
            ps1.setString(1,conference_name);
            rs1=ps1.executeQuery();
            if(rs1.next())
            {
                d.conf_name=rs1.getString("conf_name");
                d.Registration_start_date=rs1.getString("Registration_start_date");
                d.Registration_end_date=rs1.getString("Registration_end_date");
                d.abs_sub_deadline=rs1.getString("abs_sub_deadline");
                d.paper_sub_deadline=rs1.getString("paper_sub_deadline");
                d.paper_accepted_deadline=rs1.getString("paper_accepted_deadline");
                d.desciption=rs1.getString("description");
                d.charge=rs1.getInt("charge");
                d.area = rs1.getString("Area_conference");
                d.conf_id=rs1.getInt("conf_id");

            }
        } catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return d;
    }
    
    
    
    
    public static Conference GetConferenceByID(int ID) {
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        ps1=DatabaseConnection.getPreparedStatement("select * from conference_table where conf_id=?");
        try {
            ps1.setInt(1,ID);
            rs1=ps1.executeQuery();
            if(rs1.next())
            {
                d.conf_name=rs1.getString("conf_name");
                d.Registration_start_date=rs1.getString("Registration_start_date");
                d.Registration_end_date=rs1.getString("Registration_end_date");
                d.abs_sub_deadline=rs1.getString("abs_sub_deadline");
                d.paper_sub_deadline=rs1.getString("paper_sub_deadline");
                d.paper_accepted_deadline=rs1.getString("paper_accepted_deadline");
                d.desciption=rs1.getString("description");
                d.charge=rs1.getInt("charge");
                
           
            }
        } catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return d;
    }


    public static ArrayList GetConferenceTopic(String  conf_name) {
        Conference d=new Conference();
        ArrayList list=new ArrayList();
        PreparedStatement ps1;
        ResultSet rs1;
        try {
        ps1=DatabaseConnection.getPreparedStatement("select * from conference_table where conf_name=?");
        ps1.setString(1,conf_name);
        rs1=ps1.executeQuery();
        int ID=0;
        if(rs1.next())
            {
                ID = rs1.getInt("conf_id");
            }
        ps1=DatabaseConnection.getPreparedStatement("select * from conference_topics where conf_id=?");
        
            ps1.setInt(1,ID);
            rs1=ps1.executeQuery();
            while(rs1.next())
            {
                list.add(rs1.getString("topic_name"));
            }
        } catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    
    
    
    
    
     public static int GetConferenceTopicByID(String  Topic_conf_name,int Conf_id) {
        Conference d=new Conference();
        ArrayList list=new ArrayList();
        PreparedStatement ps1;
        ResultSet rs1;
        int ID=0;
        try {
        ps1=DatabaseConnection.getPreparedStatement("select * from conference_topics where conf_id=? and topic_name=?");
        ps1.setInt(1,Conf_id);
        ps1.setString(2,Topic_conf_name);
        rs1=ps1.executeQuery();
        
        if(rs1.next())
            {
                ID = rs1.getInt("topic_id");
            }
       
        } catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return ID;
    }
    
    
   
    
    
    
    
    
    public static ArrayList GetAllConferences() {
        ArrayList list = new ArrayList();
        ResultSet rs1;
        rs1 = DatabaseConnection.getResultSet("select * from conference_table");

        try {
            while (rs1.next()) {
                Conference d = new Conference();
                 d.conf_name=rs1.getString("conf_name");
                d.Registration_start_date=rs1.getString("Registration_start_date");
                d.Registration_end_date=rs1.getString("Registration_end_date");
                d.abs_sub_deadline=rs1.getString("abs_sub_deadline");
                d.paper_sub_deadline=rs1.getString("paper_sub_deadline");
                d.paper_accepted_deadline=rs1.getString("paper_accepted_deadline");
                d.desciption=rs1.getString("description");
                d.charge=rs1.getInt("charge");
                
            list.add(d);
            }

        } catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    
    public static ArrayList GetRegistrationStart(String conference_name) {
        Conference v = Conference.GetConferenceByName(conference_name);
       String strt_date =  v.Registration_start_date;
       String[] splitString = strt_date.split("\\/");
       String Month = getMonth(splitString[1]);
       ArrayList val = new ArrayList();
       val.add(splitString[0]);
       val.add(Month);
       val.add(splitString[2]);
        return val;
        
    }
    
    public static ArrayList GetRegistrationEnd(String conference_name) {
        Conference v = Conference.GetConferenceByName(conference_name);
       String strt_date =  v.Registration_end_date;
       String[] splitString = strt_date.split("\\/");
       String Month = getMonth(splitString[1]);
       ArrayList val = new ArrayList();
       val.add(splitString[0]);
       val.add(Month);
       val.add(splitString[2]);
        return val;
        
        
    }
    public static ArrayList GetAbstractEnd(String conference_name) {
        Conference v = Conference.GetConferenceByName(conference_name);
       String strt_date =  v.abs_sub_deadline;
       String[] splitString = strt_date.split("\\/");
       String Month = getMonth(splitString[1]);
       ArrayList val = new ArrayList();
       val.add(splitString[0]);
       val.add(Month);
       val.add(splitString[2]);
        return val;
        
    }
    
    
     public static int UpdateConference(String conf_name,String Area,String description,String Registratistrt,String Registratend,String Abstractsub,String Papersubmission,String DeadlineAcceptance,int charge)
    {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        int i = 0;
         ps1=DatabaseConnection.getPreparedStatement("Update conference_table set description = ?,Registration_start_date= ?,Registration_end_date = ? ,abs_sub_deadline=?,paper_sub_deadline=?,paper_accepted_deadline=?,charge=?,Area_conference=? where conf_name = '" + conf_name+"'"); 
       try {
            
        ps1.setString(1,description);
        ps1.setString(2,Registratistrt);
        ps1.setString(3,Registratend);
        ps1.setString(4,Abstractsub);
        ps1.setString(5,Papersubmission);
        ps1.setString(6,DeadlineAcceptance);
        ps1.setInt(7,charge);
        ps1.setString(8, Area);
       
        
        i = ps1.executeUpdate();
       }
        catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
       return i;
    }
    
     
     
     
          
     
  
     
     
     
     
     
     
     
     
    
    
    
    
     public static ArrayList GetPaperEnd(String conference_name) {
        Conference v = Conference.GetConferenceByName(conference_name);
       String strt_date =  v.paper_sub_deadline;
       String[] splitString = strt_date.split("\\/");
       String Month = getMonth(splitString[1]);
       ArrayList val = new ArrayList();
       val.add(splitString[0]);
       val.add(Month);
       val.add(splitString[2]);
        return val;
        
    }
    
    
    
    
    
}
