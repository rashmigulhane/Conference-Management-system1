/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Akansha Gupta
 */
public class Author extends User{

    
    PreparedStatement ps;
    ResultSet rs;

    public static ArrayList GetAllConferenceRegisteredByuser(int user_id) {
        ArrayList list = new ArrayList();
        Conference d=new Conference();
        PreparedStatement ps1;
        ResultSet rs1;
        ps1=DatabaseConnection.getPreparedStatement("select * from author_conf where user_id=?");
         try {
            
        ps1.setInt(1,user_id);
        rs1=ps1.executeQuery();
            while(rs1.next())
            {
               list.add(d.GetConferenceByID(rs1.getInt("conf_id")));
            }

        
    }
          catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }
    
    
    
    
    public static void UploadPaper(int userid,String Confname,String topic,String fileuploadname) throws IOException
    {
      Conference c =  Conference.GetConferenceByName(Confname);
      int Conf_id = c.conf_id;
      int topic_id = Conference.GetConferenceTopicByID(topic,Conf_id);
        PreparedStatement ps1;
        ResultSet rs1;
        //use the path variable here
      

        
        try
        {
        
        // String query="INSERT INTO paper_table(user_id, conf_id, topic_id, title, abstract, status,original_paper) VALUES(?,?,?,?,?,?,?)";
        String query="Update paper_table set paper_name= ?,status = ?,paper_name=? where user_id =? and Conf_id=? and topic_id=? and status=?";
         java.sql.PreparedStatement ps=DatabaseConnection.getPreparedStatement(query);
            ps.setString(1,fileuploadname);
            ps.setString(2,"Paper submitted");
            ps.setString(3,fileuploadname);
            ps.setInt(4,userid);
            ps.setInt(5,Conf_id);
            ps.setInt(6,topic_id);
            
            ps.setString(7,"Abstract submitted");
            
            
            ps.executeUpdate();
        }catch(Exception e)
        {
             Logger.getLogger(Author.class.getName()).log(Level.SEVERE, null, e);
        }
        
    }
    
    
    
    
     
    public static ArrayList ViewSubmissiion(int userid,String Confname)
    {
       Conference c =  Conference.GetConferenceByName(Confname);
      int Conf_id = c.conf_id;
      ArrayList l =new ArrayList();
      
        PreparedStatement ps1;
        ResultSet rs1;
       String st="";
        
        try
        {
        
         String query="select * from  paper_table where user_id=? and conf_id=?";
            java.sql.PreparedStatement ps=DatabaseConnection.getPreparedStatement(query);
            ps.setInt(1,userid);
            ps.setInt(2,Conf_id);
            
           rs1 =  ps.executeQuery();
           
           while (rs1.next())
           {
              l.add(Paper.getPaper(rs1.getInt("paper_id")));
           }
        }catch(Exception e)
        {
             Logger.getLogger(Author.class.getName()).log(Level.SEVERE, null, e);
        }
      return l;
    }
    
    
    
    
    
    
    
    
    
    
    
    public static void UploadAbstract(int userid,String Confname,String topic,String title,String fileuploadname)
    {
      Conference c =  Conference.GetConferenceByName(Confname);
      int Conf_id = c.conf_id;
      int topic_id = Conference.GetConferenceTopicByID(topic,Conf_id);
        PreparedStatement ps1;
        ResultSet rs1;
       
        
        try
        {
        
         String query="INSERT INTO paper_table(user_id, conf_id, topic_id, title, status,abstract_name) VALUES(?,?,?,?,?,?)";
            java.sql.PreparedStatement ps=DatabaseConnection.getPreparedStatement(query);
            ps.setInt(1,userid);
            ps.setInt(2,Conf_id);
            ps.setInt(3,topic_id);
            ps.setString(4,title);

            ps.setString(5,"Abstract submitted");
            
            ps.setString(6,fileuploadname);
            
            ps.executeUpdate();
        }catch(Exception e)
        {
             Logger.getLogger(Author.class.getName()).log(Level.SEVERE, null, e);
        }
        
    }
    
}
