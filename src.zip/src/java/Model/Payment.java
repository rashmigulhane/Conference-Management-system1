/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Akansha Gupta
 */
public class Payment {
    
    public String title;
    public int p_id;
    public int c_id;
    public int t_id;
    public int u_id;
    public String conf_name;
    public String desc;
    public String topic_name;
    public String charge;
    public String pdate;
     public static ArrayList makePayment(String user_id,String choice) throws SQLException
    {
        
        
        ArrayList a = new ArrayList();
        //get papers which are for payment
        if(choice.equals("0"))
        {
             PreparedStatement ps1;
        ResultSet rs1;
         ArrayList a1 = new ArrayList();
        ps1 = DatabaseConnection.getPreparedStatement("select * from paper_table where user_id=? and status=?");
            ps1.setInt(1, Integer.parseInt(user_id));
             ps1.setString(2, "Paper Accepted");
              rs1=ps1.executeQuery();
              while(rs1.next())
              { Payment newpay = new Payment();
               newpay.p_id =   rs1.getInt("paper_id");
               newpay.u_id =  rs1.getInt("user_id");
                newpay.c_id =  rs1.getInt("conf_id");
               newpay.t_id =   rs1.getInt("topic_id");
               newpay.title =rs1.getString("title");
             newpay.topic_name =  Conference_topic.getTopicName(newpay.t_id);
             Conference c =Conference.GetConferenceByID(newpay.c_id);
             newpay.conf_name = c.conf_name;
             newpay.desc = c.desciption;
             newpay.charge = String.valueOf(c.charge);
             newpay.pdate = c.paper_accepted_deadline;
                  a1.add(newpay);
                  
              }
        try {
            
        }catch(Exception e)
        {
            
        }
        return a1;
        
        }
        
        
        
        
    else    if(choice.equals("2"))
        {
             PreparedStatement ps1;
        ResultSet rs1;
         ArrayList a1 = new ArrayList();
        ps1 = DatabaseConnection.getPreparedStatement("select * from paper_table where user_id=? and status=?");
            ps1.setInt(1, Integer.parseInt(user_id));
             ps1.setString(2, "Payment made");
              rs1=ps1.executeQuery();
              while(rs1.next())
              { Payment newpay = new Payment();
               newpay.p_id =   rs1.getInt("paper_id");
               newpay.u_id =  rs1.getInt("user_id");
                newpay.c_id =  rs1.getInt("conf_id");
               newpay.t_id =   rs1.getInt("topic_id");
               newpay.title =rs1.getString("title");
             newpay.topic_name =  Conference_topic.getTopicName(newpay.t_id);
             Conference c =Conference.GetConferenceByID(newpay.c_id);
             newpay.conf_name = c.conf_name;
             newpay.desc = c.desciption;
             newpay.charge = String.valueOf(c.charge);
             newpay.pdate = c.paper_accepted_deadline;
                  a1.add(newpay);
                  
              }
        try {
            
        }catch(Exception e)
        {
            
        }
        return a1;
        
        }
        
        
        
        
        
        
        
        
        
      else    if(choice.equals("1"))
        {
               String query="Update paper_table set status = ? where paper_id =?";
         java.sql.PreparedStatement ps=DatabaseConnection.getPreparedStatement(query);
           
            ps.setString(1,"Payment made");
            ps.setInt(2,Integer.parseInt(user_id));
            
            
           
            
            ps.executeUpdate();
        }
        else
        {
            ArrayList a2 = new ArrayList();
            
            if (user_id.equals("ICICI")  && choice.equals("NetBanking"))
            {
                 a2.add("http://www.icicibank.com");
            }
            else if(user_id.equals("ICICI")  && choice.equals("Credit Card"))
            {     
            a2.add("http://www.icicibank.com");
           
        }
            else if(user_id.equals("ICICI")  && choice.equals("Debit Card"))
            {     
            a2.add("http://www.icicibank.com");
           
        }
            
          else  if (user_id.equals("SBI")  && choice.equals("NetBanking"))
            {
                 a2.add("https://www.onlinesbi.com");
            }
            else if(user_id.equals("SBI")  && choice.equals("Credit Card"))
            {     
            a2.add("https://www.onlinesbi.com");
           
        }
            else if(user_id.equals("SBI")  && choice.equals("Debit Card"))
            {     
            a2.add("https://www.onlinesbi.com");
           
        }
          else  if (user_id.equals("UFO")  && choice.equals("NetBanking"))
            {
                 a2.add("https://www.ucoebanking.com");
            }
            else if(user_id.equals("UFO")  && choice.equals("Credit Card"))
            {     
            a2.add("https://www.ucoebanking.com");
           
        }
            else if(user_id.equals("UFO")  && choice.equals("Debit Card"))
            {     
            a2.add("https://www.ucoebanking.com/");
           
        }
            
             else  if (user_id.equals("HDFC")  && choice.equals("NetBanking"))
            {
                 a2.add("http://www.hdfcbank.com");
            }
            else if(user_id.equals("HDFC")  && choice.equals("Credit Card"))
            {     
            a2.add("http://www.hdfcbank.com");
           
        }
            else if(user_id.equals("HDFC")  && choice.equals("Debit Card"))
            {     
            a2.add("http://www.hdfcbank.com");
           
        }
            
            
            
         return a2;
    }
      
        return null;
    
    
    
}
     
     
     
     
     
}
