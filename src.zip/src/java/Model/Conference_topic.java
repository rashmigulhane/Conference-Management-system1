/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Database_Layer.DatabaseConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Akansha Gupta
 */
public class Conference_topic {
    
    public static String getTopicName(int topicID)
    {
        String topic_name="";
        PreparedStatement ps1;
        ResultSet rs1;
        
        ps1 = DatabaseConnection.getPreparedStatement("select *  from conference_topics where topic_id=?");
         try {
            
        ps1.setInt(1,topicID);
       
        rs1=ps1.executeQuery();
            if(rs1.next())
            {
              topic_name = rs1.getString("topic_name");
            }

        
    }
          catch (SQLException ex) {
            Logger.getLogger(Conference.class.getName()).log(Level.SEVERE, null, ex);
        }
        return topic_name;
    }
    
}
