/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Akansha Gupta
 */
public class Submission_status {
    public String title;
    public String Abstract_sub;
    public String Paper_sub;
    public String Topic;
}
